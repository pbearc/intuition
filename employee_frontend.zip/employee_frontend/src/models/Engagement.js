const mongoose = require('mongoose');  // Make sure mongoose is imported

const engagementSchema = new mongoose.Schema({
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
    service: { type: mongoose.Schema.Types.ObjectId, ref: 'Service', required: true },
    startTime: { type: Date, required: true },
    endTime: { type: Date },
    duration: { type: Number }, // in seconds
    completedTasks: { type: Number, default: 0 },
    interactionCount: { type: Number, default: 0 },
    completed: { type: Boolean, default: false },
    notes: { type: String },
    created: { type: Date, default: Date.now }
  });

  // Compound index for querying
engagementSchema.index({ user: 1, service: 1, startTime: 1 });

const Engagement = mongoose.model('Engagement', engagementSchema);


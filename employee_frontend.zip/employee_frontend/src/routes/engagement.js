const express = require('express');
const router = express.Router();
const Engagement = require('../models/Engagement');
const User = require('../models/User');
const Service = require('../models/Service');

// Start tracking service engagement
router.post('/track/start', async (req, res) => {
  try {
    const { userId, serviceId } = req.body;
    
    const engagement = new Engagement({
      user: userId,
      service: serviceId,
      startTime: new Date(),
    });
    
    await engagement.save();
    
    res.status(201).json({ 
      success: true, 
      engagementId: engagement._id,
      message: 'Started tracking engagement' 
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// End tracking service engagement
router.put('/track/end/:engagementId', async (req, res) => {
  try {
    const { engagementId } = req.params;
    const { completedTasks, interactionCount, notes } = req.body;
    
    const engagement = await Engagement.findById(engagementId);
    if (!engagement) {
      return res.status(404).json({ success: false, message: 'Engagement session not found' });
    }
    
    const endTime = new Date();
    const durationInSeconds = Math.floor((endTime - engagement.startTime) / 1000);
    
    engagement.endTime = endTime;
    engagement.duration = durationInSeconds;
    engagement.completedTasks = completedTasks || 0;
    engagement.interactionCount = interactionCount || 0;
    engagement.completed = true;
    engagement.notes = notes;
    
    await engagement.save();
    
    res.status(200).json({ 
      success: true, 
      engagement: engagement,
      message: 'Ended tracking engagement' 
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get engagement analytics for a specific employee
router.get('/analytics/employee/:userId', async (req, res) => {
  try {
    const { userId } = req.params;
    const { startDate, endDate } = req.query;
    
    const query = { user: userId, completed: true };
    
    if (startDate && endDate) {
      query.startTime = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }
    
    const engagements = await Engagement.find(query)
      .populate('service', 'name category engagementMetrics')
      .sort({ startTime: -1 });
    
    // Calculate engagement metrics
    const serviceEngagement = {};
    let totalDuration = 0;
    
    engagements.forEach(engagement => {
      const serviceId = engagement.service._id.toString();
      
      if (!serviceEngagement[serviceId]) {
        serviceEngagement[serviceId] = {
          serviceName: engagement.service.name,
          category: engagement.service.category,
          metrics: engagement.service.engagementMetrics,
          sessions: 0,
          totalDuration: 0,
          averageDuration: 0,
          totalTasks: 0,
          totalInteractions: 0
        };
      }
      
      serviceEngagement[serviceId].sessions += 1;
      serviceEngagement[serviceId].totalDuration += engagement.duration;
      serviceEngagement[serviceId].totalTasks += engagement.completedTasks;
      serviceEngagement[serviceId].totalInteractions += engagement.interactionCount;
      
      totalDuration += engagement.duration;
    });
    
    // Calculate averages
    Object.keys(serviceEngagement).forEach(serviceId => {
      const service = serviceEngagement[serviceId];
      service.averageDuration = Math.floor(service.totalDuration / service.sessions);
      service.durationInMinutes = Math.floor(service.totalDuration / 60);
    });
    
    res.status(200).json({
      success: true,
      employeeId: userId,
      serviceEngagement: serviceEngagement,
      totalSessions: engagements.length,
      totalDurationInSeconds: totalDuration,
      totalDurationInMinutes: Math.floor(totalDuration / 60),
      totalDurationInHours: Math.floor(totalDuration / 3600),
      period: {
        start: startDate || 'All time',
        end: endDate || 'Now'
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get engagement analytics for a specific service
router.get('/analytics/service/:serviceId', async (req, res) => {
  try {
    const { serviceId } = req.params;
    const { startDate, endDate } = req.query;
    
    const query = { service: serviceId, completed: true };
    
    if (startDate && endDate) {
      query.startTime = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }
    
    const engagements = await Engagement.find(query)
      .populate('user', 'name department position')
      .sort({ startTime: -1 });
    
    // Calculate engagement metrics by employee
    const employeeEngagement = {};
    let totalDuration = 0;
    
    engagements.forEach(engagement => {
      const userId = engagement.user._id.toString();
      
      if (!employeeEngagement[userId]) {
        employeeEngagement[userId] = {
          name: engagement.user.name,
          department: engagement.user.department,
          position: engagement.user.position,
          sessions: 0,
          totalDuration: 0,
          averageDuration: 0,
          totalTasks: 0,
          totalInteractions: 0
        };
      }
      
      employeeEngagement[userId].sessions += 1;
      employeeEngagement[userId].totalDuration += engagement.duration;
      employeeEngagement[userId].totalTasks += engagement.completedTasks;
      employeeEngagement[userId].totalInteractions += engagement.interactionCount;
      
      totalDuration += engagement.duration;
    });
    
    // Calculate averages
    Object.keys(employeeEngagement).forEach(userId => {
      const employee = employeeEngagement[userId];
      employee.averageDuration = Math.floor(employee.totalDuration / employee.sessions);
      employee.durationInMinutes = Math.floor(employee.totalDuration / 60);
    });
    
    res.status(200).json({
      success: true,
      serviceId: serviceId,
      employeeEngagement: employeeEngagement,
      totalSessions: engagements.length,
      totalDurationInSeconds: totalDuration,
      totalDurationInMinutes: Math.floor(totalDuration / 60),
      totalDurationInHours: Math.floor(totalDuration / 3600),
      period: {
        start: startDate || 'All time',
        end: endDate || 'Now'
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Get company-wide engagement dashboard data
router.get('/analytics/dashboard', async (req, res) => {
  try {
    const { startDate, endDate, department } = req.query;
    
    const query = { completed: true };
    
    if (startDate && endDate) {
      query.startTime = { 
        $gte: new Date(startDate), 
        $lte: new Date(endDate) 
      };
    }
    
    // Get all engagements
    const engagements = await Engagement.find(query)
      .populate('user', 'name department position')
      .populate('service', 'name category engagementMetrics')
      .sort({ startTime: -1 });
    
    // Filter by department if specified
    let filteredEngagements = engagements;
    if (department) {
      filteredEngagements = engagements.filter(
        engagement => engagement.user.department === department
      );
    }
    
    // Calculate service popularity
    const serviceUsage = {};
    const employeeEngagement = {};
    let totalDuration = 0;
    
    filteredEngagements.forEach(engagement => {
      const serviceId = engagement.service._id.toString();
      const userId = engagement.user._id.toString();
      
      // Service metrics
      if (!serviceUsage[serviceId]) {
        serviceUsage[serviceId] = {
          name: engagement.service.name,
          category: engagement.service.category,
          sessions: 0,
          uniqueUsers: new Set(),
          totalDuration: 0,
          totalTasks: 0
        };
      }
      
      serviceUsage[serviceId].sessions += 1;
      serviceUsage[serviceId].uniqueUsers.add(userId);
      serviceUsage[serviceId].totalDuration += engagement.duration;
      serviceUsage[serviceId].totalTasks += engagement.completedTasks;
      
      // Employee metrics
      if (!employeeEngagement[userId]) {
        employeeEngagement[userId] = {
          name: engagement.user.name,
          department: engagement.user.department,
          uniqueServices: new Set(),
          sessions: 0,
          totalDuration: 0
        };
      }
      
      employeeEngagement[userId].uniqueServices.add(serviceId);
      employeeEngagement[userId].sessions += 1;
      employeeEngagement[userId].totalDuration += engagement.duration;
      
      totalDuration += engagement.duration;
    });
    
    // Convert Sets to counts and calculate averages
    Object.keys(serviceUsage).forEach(id => {
      serviceUsage[id].uniqueUserCount = serviceUsage[id].uniqueUsers.size;
      serviceUsage[id].uniqueUsers = [...serviceUsage[id].uniqueUsers]; // Convert to array if needed
      serviceUsage[id].averageDuration = Math.floor(serviceUsage[id].totalDuration / serviceUsage[id].sessions);
    });
    
    Object.keys(employeeEngagement).forEach(id => {
      employeeEngagement[id].uniqueServiceCount = employeeEngagement[id].uniqueServices.size;
      employeeEngagement[id].uniqueServices = [...employeeEngagement[id].uniqueServices]; // Convert to array if needed
      employeeEngagement[id].averageDuration = Math.floor(employeeEngagement[id].totalDuration / employeeEngagement[id].sessions);
      employeeEngagement[id].engagementScore = calculateEngagementScore(employeeEngagement[id]);
    });
    
    res.status(200).json({
      success: true,
      serviceUsage,
      employeeEngagement,
      totalSessions: filteredEngagements.length,
      totalDurationInHours: Math.floor(totalDuration / 3600),
      averageSessionDuration: Math.floor(totalDuration / filteredEngagements.length),
      period: {
        start: startDate || 'All time',
        end: endDate || 'Now'
      },
      departmentFilter: department || 'All departments'
    });
  } catch (error) {
    res.status(500).json({ success: false, message: error.message });
  }
});

// Helper function to calculate engagement score
function calculateEngagementScore(employeeData) {
  // This is a simple example - customize based on your metrics
  const sessionWeight = 0.3;
  const durationWeight = 0.4;
  const servicesWeight = 0.3;
  
  // Normalize values (assuming some reasonable max values)
  const sessionScore = Math.min(employeeData.sessions / 20, 1) * sessionWeight;
  const durationScore = Math.min(employeeData.totalDuration / (3600 * 8), 1) * durationWeight; // 8 hours max
  const servicesScore = Math.min(employeeData.uniqueServiceCount / 5, 1) * servicesWeight; // 5 services max
  
  return ((sessionScore + durationScore + servicesScore) * 100).toFixed(1);
}

module.exports = router;
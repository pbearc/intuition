import React from "react";
import { Link } from "react-router-dom";
import {
  ChatAlt2Icon,
  BookOpenIcon,
  ArchiveIcon,
  LightningBoltIcon,
  UserGroupIcon,
  DocumentTextIcon,
  ChartBarIcon,
} from "@heroicons/react/outline";
import GitContributionGraph from "../components/GitContributionGraph";
import TeamEngagementChart from "../components/TeamEngagementChart";
import UserTierComponent from "../components/UserTierComponent";
import CozeAIChatbot from "../components/CozeAIChatbot";

const Dashboard = () => {
  // Mock user data - in production, you'd fetch this from your API
  const userData = {
    name: "JiaYee Chong",
    email: "jyee@example.com",
    engagement: {
      averageLastWeek: 78,
      history: [65, 72, 80, 75, 82, 85, 78],
      streakDays: 14,
    },
  };

  return (
    <div className="h-full">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Dashboard</h1>
        <p className="text-gray-600">
          Overview of Jia Yee's change management activities
        </p>
      </div>

      <div>
        <UserTierComponent />
      </div>

      <GitContributionGraph />
      <div className="h-10"></div>
      <TeamEngagementChart />

      <CozeAIChatbot userData={userData} />
      <div className="text-white">
        g
      </div>
    </div>
  );
};

export default Dashboard;

import React, { useState } from "react";
import { ExternalLink, Search } from "lucide-react";

const Services = () => {
  const [searchTerm, setSearchTerm] = useState("");
  
  // Sample services data - you would replace this with your actual services
  const services = [
    {
      id: 1,
      name: "ChatGPT",
      description: "AI assistant for content generation and answering questions",
      icon: "🤖",
      url: "https://chat.openai.com",
      category: "AI",
    },
    {
      id: 4,
      name: "DALL·E",
      description: "AI model by OpenAI to generate images from textual descriptions",
      icon: "🖼️",
      url: "https://openai.com/dall-e",
      category: "AI",
    },
    {
      id: 2,
      name: "Notion",
      description: "All-in-one workspace for notes, documents, and project management",
      icon: "📝",
      url: "https://notion.so",
      category: "Productivity",
    },
    {
      id: 3,
      name: "Slack",
      description: "Business communication platform for messaging and file sharing",
      icon: "💬",
      url: "https://slack.com",
      category: "Communication",
    },
    {
      id: 4,
      name: "Microsoft Teams",
      description: "Collaboration platform with video meetings and file sharing",
      icon: "👥",
      url: "https://teams.microsoft.com",
      category: "Communication",
    },
    {
      id: 5,
      name: "Miro",
      description: "Online collaborative whiteboard platform",
      icon: "🖌️",
      url: "https://miro.com",
      category: "Collaboration",
    },
    {
      id: 6,
      name: "Jira",
      description: "Issue and project tracking software",
      icon: "📊",
      url: "https://jira.atlassian.com",
      category: "Project Management",
    },
  ];

  // Filter services based on search term
  const filteredServices = services.filter(service => 
    service.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
    service.category.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // Group services by category
  const servicesByCategory = filteredServices.reduce((acc, service) => {
    if (!acc[service.category]) {
      acc[service.category] = [];
    }
    acc[service.category].push(service);
    return acc;
  }, {});

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-2xl font-bold mb-6">Company Services</h1>
      
      {/* Search bar */}
      <div className="mb-8 relative">
        <div className="relative">
          <input
            type="text"
            placeholder="Search services..."
            className="w-full pl-10 pr-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={18} />
        </div>
      </div>

      {/* Services list by category */}
      {Object.keys(servicesByCategory).length > 0 ? (
        Object.entries(servicesByCategory).map(([category, categoryServices]) => (
          <div key={category} className="mb-8">
            <h2 className="text-xl font-semibold mb-4 text-gray-700">{category}</h2>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {categoryServices.map((service) => (
                <div 
                  key={service.id} 
                  className="bg-white rounded-lg shadow hover:shadow-md transition-shadow p-6 border border-gray-200"
                >
                  <div className="flex justify-between items-start">
                    <div className="flex items-center">
                      <span className="text-2xl mr-3">{service.icon}</span>
                      <h3 className="text-lg font-medium">{service.name}</h3>
                    </div>
                    <a 
                      href={service.url} 
                      target="_blank" 
                      rel="noopener noreferrer"
                      className="text-blue-500 hover:text-blue-700"
                    >
                      <ExternalLink size={18} />
                    </a>
                  </div>
                  <p className="mt-2 text-gray-600">{service.description}</p>
                  <div className="mt-4">
                    <a 
                      href={service.url} 
                      target="_blank" 
                      rel="noopener noreferrer" 
                      className="inline-flex items-center text-sm font-medium text-blue-600 hover:text-blue-800"
                    >
                      Access Service
                      <ExternalLink size={14} className="ml-1" />
                    </a>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-500">No services found matching your search.</p>
        </div>
      )}
    </div>
  );
};

export default Services;

// src/pages/ServicePerformance.js - Service performance dashboard
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { 
  BarChart, Bar, LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer 
} from 'recharts';
import { Filter, Download } from 'lucide-react';

const ServicePerformance = () => {
  const [services, setServices] = useState([]);
  const [selectedService, setSelectedService] = useState('');
  const [dateRange, setDateRange] = useState({
    startDate: new Date(new Date().setDate(new Date().getDate() - 30)).toISOString().split('T')[0],
    endDate: new Date().toISOString().split('T')[0]
  });
  const [performanceData, setPerformanceData] = useState(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchServices();
  }, []);

  const fetchServices = async () => {
    try {
      const response = await axios.get('/api/services');
      setServices(response.data.services);
      if (response.data.services.length > 0) {
        setSelectedService(response.data.services[0]._id);
      }
    } catch (error) {
      console.error('Error fetching services:', error);
    }
  };

  const fetchPerformanceData = async () => {
    if (!selectedService) return;
    
    setLoading(true);
    try {
      const params = new URLSearchParams({
        startDate: dateRange.startDate,
        endDate: dateRange.endDate
      });
      
      const response = await axios.get(`/api/engagement/analytics/service/${selectedService}?${params}`);
      setPerformanceData(response.data);
    } catch (error) {
      console.error('Error fetching performance data:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (selectedService) {
      fetchPerformanceData();
    }
  }, [selectedService]);

  const handleFilterChange = () => {
    fetchPerformanceData();
  };

  const exportCSV = () => {
    if (!performanceData) return;
    
    // Create CSV content
    let csvContent = "data:text/csv;charset=utf-8,";
    
    // Headers
    csvContent += "Employee,Department,Position,Sessions,Total Duration (min),Average Duration (min),Tasks Completed\n";
    
    // Data rows
    Object.values(performanceData.employeeEngagement).forEach(employee => {
      csvContent += `${employee.name},${employee.department},${employee.position},${employee.sessions},${Math.floor(employee.totalDuration / 60)},${Math.floor(employee.averageDuration / 60)},${employee.totalTasks}\n`;
    });
    
    // Create download link
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement("a");
    link.setAttribute("href", encodedUri);
    link.setAttribute("download", `service_usage_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    
    // Trigger download
    link.click();
  };

  const formatEmployeeData = () => {
    if (!performanceData) return [];
    
    return Object.values(performanceData.employeeEngagement)
      .sort((a, b) => b.totalDuration - a.totalDuration)
      .slice(0, 10)
      .map(employee => ({
        name: employee.name,
        minutes: Math.floor(employee.totalDuration / 60),
        sessions: employee.sessions,
        tasks: employee.totalTasks
      }));
  };

  const formatWeeklyTrends = () => {
    if (!performanceData) return [];
    
    // This would require additional API endpoint to get weekly trends
    // Mocking data for example purposes
    return [
      { week: 'Week 1', users: 35, sessions: 120, avgTime: 22 },
      { week: 'Week 2', users: 42, sessions: 148, avgTime: 25 },
      { week: 'Week 3', users: 38, sessions: 132, avgTime: 21 },
      { week: 'Week 4', users: 44, sessions: 165, avgTime: 24 }
    ];
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-2xl font-bold">Service Performance Analytics</h1>
        <button 
          onClick={exportCSV}
          disabled={!performanceData}
          className="flex items-center bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded disabled:opacity-50 disabled:cursor-not-allowed"
        >
          <Download size={16} className="mr-2" />
          Export Data
        </button>
      </div>
      
      {/* Filters */}
      <div className="bg-white rounded-lg shadow p-4 mb-6">
        <div className="flex flex-wrap gap-4">
          <div className="flex-1">
            <label className="block text-sm text-gray-600 mb-1">Select Service</label>
            <select
              className="w-full border rounded p-2"
              value={selectedService}
              onChange={(e) => setSelectedService(e.target.value)}
            >
              {services.map(service => (
                <option key={service._id} value={service._id}>{service.name}</option>
              ))}
            </select>
          </div>
          <div className="flex-1">
            <label className="block text-sm text-gray-600 mb-1">Start Date</label>
            <input
              type="date"
              className="w-full border rounded p-2"
              value={dateRange.startDate}
              onChange={(e) => setDateRange({...dateRange, startDate: e.target.value})}
            />
          </div>
          <div className="flex-1">
            <label className="block text-sm text-gray-600 mb-1">End Date</label>
            <input
              type="date"
              className="w-full border rounded p-2"
              value={dateRange.endDate}
              onChange={(e) => setDateRange({...dateRange, endDate: e.target.value})}
            />
          </div>
          <div className="flex items-end">
            <button 
              className="flex items-center bg-gray-100 hover:bg-gray-200 text-gray-700 py-2 px-4 rounded transition-colors"
              onClick={handleFilterChange}
            >
              <Filter size={16} className="mr-2" />
              Apply Filters
            </button>
          </div>
        </div>
      </div>
      
      {loading ? (
        <div className="flex justify-center items-center h-64">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-500"></div>
        </div>
      ) : performanceData ? (
        <>
          {/* Service Overview */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-gray-500 text-sm mb-1">Total Usage</h3>
              <p className="text-2xl font-semibold">{performanceData.totalSessions} sessions</p>
              <p className="text-sm text-gray-600">{performanceData.totalDurationInHours} hours total</p>
            </div>
            
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-gray-500 text-sm mb-1">Average Session</h3>
              <p className="text-2xl font-semibold">{Math.floor(performanceData.totalDurationInMinutes / performanceData.totalSessions)} minutes</p>
              <p className="text-sm text-gray-600">per user session</p>
            </div>
            
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="text-gray-500 text-sm mb-1">Unique Users</h3>
              <p className="text-2xl font-semibold">{Object.keys(performanceData.employeeEngagement).length}</p>
              <p className="text-sm text-gray-600">active users in period</p>
            </div>
          </div>
          
          {/* Charts */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
            {/* Top Users Chart */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-medium mb-4">Top Users by Time Spent</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={formatEmployeeData()}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                    layout="vertical"
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis type="number" />
                    <YAxis dataKey="name" type="category" width={100} />
                    <Tooltip />
                    <Legend />
                    <Bar dataKey="minutes" name="Minutes" fill="#0088FE" />
                  </BarChart>
                </ResponsiveContainer>
              </div>
            </div>
            
            {/* Weekly Trends */}
            <div className="bg-white rounded-lg shadow p-4">
              <h3 className="font-medium mb-4">Weekly Usage Trends</h3>
              <div className="h-72">
                <ResponsiveContainer width="100%" height="100%">
                  <LineChart
                    data={formatWeeklyTrends()}
                    margin={{ top: 5, right: 30, left: 20, bottom: 5 }}
                  >
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="week" />
                    <YAxis />
                    <Tooltip />
                    <Legend />
                    <Line type="monotone" dataKey="users" stroke="#0088FE" name="Active Users" />
                    <Line type="monotone" dataKey="sessions" stroke="#00C49F" name="Sessions" />
                    <Line type="monotone" dataKey="avgTime" stroke="#FFBB28" name="Avg Minutes" />
                  </LineChart>
                </ResponsiveContainer>
              </div>
            </div>
          </div>
          
          {/* Employee List */}
          <div className="bg-white rounded-lg shadow p-4 mb-6">
            <h3 className="font-medium mb-4">Employee Usage Details</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead>
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Employee</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Department</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sessions</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Total Time</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Avg Session</th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tasks</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {Object.values(performanceData.employeeEngagement)
                    .sort((a, b) => b.totalDuration - a.totalDuration)
                    .map((employee, index) => (
                      <tr key={index} className={index % 2 === 0 ? 'bg-gray-50' : ''}>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <div className="font-medium text-gray-900">{employee.name}</div>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">{employee.department}</td>
                        <td className="px-6 py-4 whitespace-nowrap">{employee.sessions}</td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {Math.floor(employee.totalDuration / 60)} min
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          {Math.floor(employee.averageDuration / 60)} min
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">{employee.totalTasks}</td>
                      </tr>
                    ))}
                </tbody>
              </table>
            </div>
          </div>
        </>
      ) : (
        <div className="text-center py-8">
          <p className="text-gray-500">Select a service to view performance data.</p>
        </div>
      )}
    </div>
  );
};

export default ServicePerformance;

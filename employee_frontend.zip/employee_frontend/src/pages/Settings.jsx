import React, { useState, useEffect } from 'react';
import md5 from 'md5'; // For Gravatar
import { 
  User, 
  Bell, 
  Lock, 
  // Settings,
  Sparkles,
  Flame,
  Zap,
  Star
} from 'lucide-react';

// const UserTierComponent = () => {
//   const [userData, setUserData] = useState({
//     name: "JiaYee Chong",
//     email: "jyee@example.com",
//     engagement: {
//       averageLastWeek: 78,
//       history: [65, 72, 80, 75, 82, 85, 78],
//       streakDays: 14
//     }
//   });

//   useEffect(() => {
//     fetch("/api/user/engagement") // Replace with real API
//       .then(res => res.json())
//       .then(data => setUserData(data))
//       .catch(err => console.error("Error fetching data:", err));
//   }, []);

//   const getTierInfo = (engagement) => {
//     if (engagement >= 90) return { name: "Diamond Explorer", color: "bg-blue-500", textColor: "text-blue-600", borderColor: "border-blue-400", description: "Leading the change movement!", icon: Star };
//     if (engagement >= 75) return { name: "Gold Innovator", color: "bg-yellow-500", textColor: "text-yellow-600", borderColor: "border-yellow-400", description: "Consistently driving impact!", icon: Zap };
//     if (engagement >= 50) return { name: "Silver Changer", color: "bg-gray-400", textColor: "text-gray-600", borderColor: "border-gray-400", description: "Making steady progress!", icon: Flame };
//     return { name: "Bronze Starter", color: "bg-orange-400", textColor: "text-orange-600", borderColor: "border-orange-400", description: "Beginning your change journey!", icon: Sparkles };
//   };

//   const tier = getTierInfo(userData.engagement.averageLastWeek);

//   const AvatarGenerator = ({ engagement, tierInfo }) => {
//     const expressions = ["😊", "🙂", "😄", "😎"];
//     const badges = ["🥉", "🥈", "🏆", "💎"];
//     const index = engagement >= 90 ? 3 : engagement >= 75 ? 2 : engagement >= 50 ? 1 : 0;

//     return (
//       <div className={`relative h-16 w-16 rounded-full flex items-center justify-center text-2xl ${tierInfo.color} text-white`}>
//         {/* {expressions[index]} */}
//                 <img 
//           src={`https://media.licdn.com/dms/image/v2/D5603AQFnAkiAXQJJ3Q/profile-displayphoto-shrink_200_200/B56ZUDleFfHQAY-/0/1739521910584?e=1747872000&v=beta&t=YIhBYiLu8-k2kseD4S-y8J_dgBf69KZZFRvT8-aE33o`} 
//           alt="Profile" 
//           className="h-26 w-26 rounded-full object-cover border-2 border-gray-200"
//         />

//         <div className="absolute -top-1 -left-1 ">{badges[index]}</div>
//       </div>
//     );
//   };

//   const EngagementChart = ({ data }) => {
//     const max = Math.max(...data);

//     return (
//       <div className="flex items-end h-12 gap-1">
//         {data.map((value, index) => (
//           <div 
//             key={index}
//             className={`w-20 ${getTierInfo(value).color} rounded-t flex items-center justify-center min-h-100`}
//             style={{ height: `${(value / max) * 100 + 30}%`, minHeight: "40px" }}
//           >
//             <span className="text-xs text-white">{value}</span>
//           </div>
//         ))}
//       </div>
//     );
//   };

//   return (
//     <div className={`mb-8 p-12 rounded-lg border-2 ${tier.borderColor} bg-white`}>
//       <h3 className="text-lg font-semibold mb-2 flex items-center">
//         <span>Your Engagement Tier</span>
//         <span className={`ml-2 px-2 py-1 text-xs font-bold rounded-full ${tier.color} text-white`}>NEW</span>
//       </h3>

//       <div className="flex items-center">

//         <div className="mx-4">
//           <AvatarGenerator engagement={userData.engagement.averageLastWeek} tierInfo={tier} />
//         </div>

//         <div>
//           <h4 className={`font-bold text-lg ${tier.textColor}`}>{tier.name}</h4>
//           <p className="text-gray-600 text-sm">{tier.description}</p>
//           <div className="flex items-center mt-1">
//             <tier.icon className={`h-4 w-4 ${tier.textColor} mr-1`} />
//             <span className="text-xs font-medium">{userData.engagement.streakDays} day streak</span>
//           </div>
//         </div>
//       </div>

//       <div className="mt-4 flex-col">
//         <div className="flex justify-between items-center mb-1 text-lg pb-6">
//           <span className=" font-medium text-gray-600">Last Week's Engagement</span>
//           <span className={` font-bold ${tier.textColor}`}>{userData.engagement.averageLastWeek}%</span>
//         </div>
//         <div className='flex justify-center'>
//         <EngagementChart data={userData.engagement.history} />

//         </div>
//       </div>

//       <div className="mt-4 text-center">
//         <button className={`px-4 py-2 ${tier.color} text-white rounded-md text-sm font-medium hover:opacity-90 transition-opacity`}>
//           View Engagement Details
//         </button>
//       </div>
//     </div>
//   );
// };

const Settings = () => {
  return (
    <div>
      <h2 className="text-lg font-semibold text-gray-800 mb-4">Profile Settings</h2>

      {/* <UserTierComponent /> */}

      <form className="space-y-5">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div>
            <label htmlFor="firstName" className="block text-sm font-medium text-gray-700 mb-1">First Name</label>
            <input type="text" id="firstName" name="firstName" defaultValue="JiaYee" className="w-full p-2 border border-gray-300 rounded-md" />
          </div>

          <div>
            <label htmlFor="lastName" className="block text-sm font-medium text-gray-700 mb-1">Last Name</label>
            <input type="text" id="lastName" name="lastName" defaultValue="Chong" className="w-full p-2 border border-gray-300 rounded-md" />
          </div>
        </div>

        <div>
          <label htmlFor="email" className="block text-sm font-medium text-gray-700 mb-1">Email Address</label>
          <input type="email" id="email" name="email" defaultValue="jyee@example.com" className="w-full p-2 border border-gray-300 rounded-md" />
        </div>

        <div>
          <label htmlFor="bio" className="block text-sm font-medium text-gray-700 mb-1">Bio</label>
          <textarea id="bio" name="bio" rows="4" defaultValue="Enthusiastic about changing the world!" className="w-full p-2 border border-gray-300 rounded-md"></textarea>
        </div>

        <div className="flex justify-end">
          <button type="button" className="px-4 py-2 border border-gray-300 text-gray-700 rounded-md text-sm font-medium hover:bg-gray-50 mr-3">Cancel</button>
          <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md text-sm font-medium hover:bg-blue-700">Save Changes</button>
        </div>
      </form>
    </div>
  );
};

export default Settings;

import React from 'react';
import { ShieldCheckIcon, StarIcon, SparklesIcon, FireIcon } from '@heroicons/react/solid';

const getUserTier = (engagementScore) => {
  if (engagementScore >= 80) {
    return { tier: 'Platinum', icon: SparklesIcon, color: 'text-purple-600' };
  } else if (engagementScore >= 60) {
    return { tier: 'Gold', icon: StarIcon, color: 'text-yellow-500' };
  } else if (engagementScore >= 40) {
    return { tier: 'Silver', icon: ShieldCheckIcon, color: 'text-gray-500' };
  } else {
    return { tier: 'Bronze', icon: FireIcon, color: 'text-orange-500' };
  }
};

const UserTierBadge = ({ engagementScore }) => {
  const { tier, icon: Icon, color } = getUserTier(engagementScore);
  
  return (
    <div className="flex items-center space-x-3 bg-gray-100 p-3 rounded-lg shadow-md">
      <Icon className={`h-6 w-6 ${color}`} />
      <span className="font-semibold text-gray-800">{tier} Tier</span>
    </div>
  );
};


export default UserTierBadge;

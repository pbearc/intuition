import { useEffect } from "react";

const CozeAIChatbot = ({ userData }) => {
  useEffect(() => {
    // Check if the script is already loaded to avoid duplication
    if (!window.CozeWebSDK) {
      const script = document.createElement("script");
      script.src =
        "https://sf-cdn.coze.com/obj/unpkg-va/flow-platform/chat-app-sdk/1.2.0-beta.5/libs/oversea/index.js";
      script.async = true;
      script.onload = () => {
        if (window.CozeWebSDK) {
          new window.CozeWebSDK.WebChatClient({
            config: {
              bot_id: "7484679564636405768",
            },
            auth: {
              type: "token",
              token: "*",
              onRefreshToken: () => {
                return "*";
              },
            },
          });
        } else {
          console.error("Coze SDK failed to load.");
        }
      };

      document.body.appendChild(script);
    }
  }, [userData]);

  return null; // No UI element needed, Coze handles rendering
};

export default CozeAIChatbot;

import React from "react";
import { Link, useLocation } from "react-router-dom";
import {
  Home,
  MessageSquare,
  Book,
  Gamepad2,
  Settings,
  ExternalLink,
  UserPlus, // Added for Services icon
} from "lucide-react";
import logo from "../../assets/a.jpg";

const Sidebar = ({ isOpen, setIsOpen }) => {
  const location = useLocation();

  const navItems = [
    { path: "/", name: "Dashboard", icon: <Home size={20} /> },
    {
      path: "/assistant",
      name: "Chatbot Assistant",
      icon: <MessageSquare size={20} />,
    },
    // { path: "/knowledge", name: "Knowledge Hub", icon: <Book size={20} /> },
    // { path: "/campaigns", name: "Past Campaigns", icon: <BarChart2 size={20} /> },
    { path: "/services", name: "Services", icon: <ExternalLink size={20} /> }, // Added Services link
    {
      path: "/gamified_services",
      name: "Gamified Services",
      icon: <Gamepad2 size={20} />,
    },
    { path: "/settings", name: "Settings", icon: <Settings size={20} /> },
    // { path: "/engagement", name: "Engagement", icon: <UserPlus size={20} /> },
  ];

  return (
    <>
      {/* Mobile sidebar backdrop */}
      {isOpen && (
        <div
          className="fixed inset-0 z-20 bg-black bg-opacity-50 lg:hidden"
          onClick={() => setIsOpen(false)}
        ></div>
      )}

      {/* Sidebar */}
      <div
        className={`fixed inset-y-0 left-0 z-30 w-64 bg-white shadow-lg transform ${
          isOpen ? "translate-x-0" : "-translate-x-full"
        } lg:translate-x-0 transition-transform duration-300 ease-in-out`}
      >
        <div className="flex flex-col h-full">
          {/* Logo */}
          <div className="flex items-center justify-center h-16 border-b">
            <img
              src={logo}
              alt=""
              className="w-20 h-10 rounded-full object-cover"
            />
            <span className="text-xl font-bold text-gray-800 mr-3">
              MSD
            </span>
          </div>

          {/* Nav items */}
          <nav className="flex-1 px-2 py-4 space-y-1 overflow-y-auto">
            {navItems.map((item) => (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center px-4 py-2 rounded-md ${
                  location.pathname === item.path
                    ? "bg-blue-500 text-white"
                    : "text-gray-700 hover:bg-gray-100"
                }`}
              >
                {item.icon}
                <span className="ml-3">{item.name}</span>
              </Link>
            ))}
          </nav>

          {/* User info */}
          <div className="flex items-center p-4 border-t">
            <img
              src="https://media.licdn.com/dms/image/v2/D5603AQFnAkiAXQJJ3Q/profile-displayphoto-shrink_200_200/B56ZUDleFfHQAY-/0/1739521910584?e=1747872000&v=beta&t=YIhBYiLu8-k2kseD4S-y8J_dgBf69KZZFRvT8-aE33o"
              alt="Profile"
              className="h-10 w-10 rounded-full object-cover border"
            />
            <div className="ml-3">
              <p className="text-sm font-medium text-gray-700">Jia Yee</p>
              <p className="text-xs text-gray-500">jyee@example.com</p>
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default Sidebar;

import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Clock } from 'lucide-react';

const EngagementTracker = ({ serviceId, userId }) => {
  const [tracking, setTracking] = useState(false);
  const [startTime, setStartTime] = useState(null);
  const [duration, setDuration] = useState(0);
  const [engagementId, setEngagementId] = useState(null);
  const [completedTasks, setCompletedTasks] = useState(0);
  const [interactions, setInteractions] = useState(0);
  const [notes, setNotes] = useState('');

  useEffect(() => {
    let interval;
    if (tracking) {
      interval = setInterval(() => {
        const elapsed = Math.floor((new Date() - startTime) / 1000);
        setDuration(elapsed);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [tracking, startTime]);

  const startTracking = async () => {
    try {
      const response = await axios.post('/api/engagement/track/start', {
        userId,
        serviceId
      });
      
      if (response.data.success) {
        setEngagementId(response.data.engagementId);
        setStartTime(new Date());
        setTracking(true);
      }
    } catch (error) {
      console.error('Error starting tracking:', error);
    }
  };

  const stopTracking = async () => {
    try {
      const response = await axios.put(`/api/engagement/track/end/${engagementId}`, {
        completedTasks,
        interactionCount: interactions,
        notes
      });
      
      if (response.data.success) {
        setTracking(false);
        setStartTime(null);
        setDuration(0);
        setCompletedTasks(0);
        setInteractions(0);
        setNotes('');
      }
    } catch (error) {
      console.error('Error stopping tracking:', error);
    }
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const incrementInteraction = () => {
    setInteractions(prev => prev + 1);
  };

  return (
    <div className="fixed bottom-0 right-0 bg-white border rounded-tl-lg shadow-lg p-4 m-4 w-64">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-lg">Service Tracker</h3>
        <Clock size={20} className="text-blue-500" />
      </div>
      
      <div className="mb-4 text-center">
        <div className="text-2xl font-mono">{formatDuration(duration)}</div>
        <div className="text-xs text-gray-500">Time spent on this service</div>
      </div>
      
      {tracking && (
        <>
          <div className="grid grid-cols-2 gap-2 mb-4">
            <div className="border rounded p-2 text-center">
              <div className="text-lg font-semibold">{completedTasks}</div>
              <button 
                className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded"
                onClick={() => setCompletedTasks(prev => prev + 1)}
              >
                Add Task
              </button>
            </div>
            <div className="border rounded p-2 text-center">
              <div className="text-lg font-semibold">{interactions}</div>
              <button 
                className="text-xs bg-blue-50 text-blue-600 px-2 py-1 rounded"
                onClick={incrementInteraction}
              >
                Add Interaction
              </button>
            </div>
          </div>
          
          <div className="mb-3">
            <label className="block text-sm text-gray-600 mb-1">Session Notes</label>
            <textarea
              className="w-full border rounded p-2 text-sm"
              rows="2"
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Add notes about this session..."
            />
          </div>
        </>
      )}
      
      {!tracking ? (
        <button
          className="w-full bg-blue-500 hover:bg-blue-600 text-white py-2 px-4 rounded transition-colors"
          onClick={startTracking}
        >
          Start Tracking
        </button>
      ) : (
        <button
          className="w-full bg-red-500 hover:bg-red-600 text-white py-2 px-4 rounded transition-colors"
          onClick={stopTracking}
        >
          End Session
        </button>
      )}
    </div>
  );
};

export default EngagementTracker;
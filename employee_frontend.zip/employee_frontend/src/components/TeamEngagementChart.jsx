import React, { useState } from 'react';

const TeamEngagementChart = () => {
  // Mock data for team engagement
  const [teams] = useState([
    { 
      name: "Product", 
      engagement: 87,
      trend: "up",
      history: [65, 70, 75, 78, 82, 87]
    },
    { 
      name: "Engineering", 
      engagement: 92,
      trend: "up",
      history: [84, 86, 89, 90, 91, 92]
    },
    { 
      name: "Marketing", 
      engagement: 78,
      trend: "down",
      history: [82, 85, 84, 80, 79, 78]
    },
    { 
      name: "Sales", 
      engagement: 83,
      trend: "up",
      history: [76, 75, 79, 80, 82, 83]
    },
    { 
      name: "Support", 
      engagement: 75,
      trend: "down",
      history: [80, 82, 79, 78, 76, 75]
    },
    { 
      name: "Design", 
      engagement: 89,
      trend: "stable",
      history: [88, 87, 89, 90, 88, 89]
    }
  ]);

  // Function to determine color based on engagement value
  const getColor = (value) => {
    if (value >= 90) return '#fb4d56'; // Bright red (highest)
    if (value >= 80) return '#af3a3d';
    if (value >= 70) return '#84373a';
    if (value >= 60) return '#5e2f33';
    return '#3a2e2f'; // Dark maroon (lowest)
  };

  // Function to render trend indicator
  const renderTrendIndicator = (trend) => {
    if (trend === "up") {
      return (
        <svg className="w-4 h-4 text-green-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 10l7-7m0 0l7 7m-7-7v18"></path>
        </svg>
      );
    } else if (trend === "down") {
      return (
        <svg className="w-4 h-4 text-red-500" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 14l-7 7m0 0l-7-7m7 7V3"></path>
        </svg>
      );
    } else {
      return (
        <svg className="w-4 h-4 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 12h14"></path>
        </svg>
      );
    }
  };

  // Function to render sparkline
  const renderSparkline = (history) => {
    if (!history || history.length === 0) return null;
    
    const max = Math.max(...history);
    const min = Math.min(...history);
    const range = max - min || 1;
    const width = 80;
    const height = 24;
    const padding = 2;
    
    // Calculate points for the sparkline
    const points = history.map((value, index) => {
      const x = (index / (history.length - 1)) * (width - padding * 2) + padding;
      const normalizedValue = (value - min) / range;
      const y = height - (normalizedValue * (height - padding * 2) + padding);
      return `${x},${y}`;
    }).join(' ');
    
    return (
      <svg width={width} height={height} className="overflow-visible">
        <polyline
          points={points}
          fill="none"
          stroke="#4a5568"
          strokeWidth="1.5"
        />
      </svg>
    );
  };

  return (
    <div className="w-full bg-gray-900 rounded-lg overflow-hidden shadow-lg">
      <div className="px-6 py-4 border-b border-gray-800">
        <h2 className="text-xl font-semibold text-white">Team Engagement Rates</h2>
      </div>
      
      <div className="p-2">
        {teams.map((team, index) => (
          <div key={team.name} className="flex items-center p-3 hover:bg-gray-800 rounded-md transition-colors">
            <div className="w-32 font-medium text-gray-200">{team.name}</div>
            
            <div className="flex-1 flex items-center">
              {/* Progress bar */}
              <div className="w-full bg-gray-700 rounded-full h-4 mr-3">
                <div 
                  className="h-4 rounded-full transition-all duration-500"
                  style={{ 
                    width: `${team.engagement}%`,
                    backgroundColor: getColor(team.engagement) 
                  }}
                ></div>
              </div>
              
              {/* Percentage and trend */}
              <div className="w-16 flex items-center">
                <span className="font-bold text-gray-200">{team.engagement}%</span>
                <span className="ml-1">{renderTrendIndicator(team.trend)}</span>
              </div>
              
              {/* Sparkline */}
              <div className="w-20 flex justify-end">
                {renderSparkline(team.history)}
              </div>
            </div>
          </div>
        ))}
      </div>
      
      {/* Legend */}
      <div className="px-6 py-3 border-t border-gray-800 flex items-center justify-end">
        <span className="text-gray-400 text-xs mr-2">Engagement:</span>
        <div className="flex items-center">
          <span className="text-gray-400 text-xs mr-1">Lower</span>
          {['#3a2e2f', '#5e2f33', '#84373a', '#af3a3d', '#fb4d56'].map(color => (
            <div 
              key={color} 
              className="w-3 h-3 mx-px rounded-sm"
              style={{ backgroundColor: color }}
            />
          ))}
          <span className="text-gray-400 text-xs ml-1">Higher</span>
        </div>
      </div>
    </div>
  );
};

export default TeamEngagementChart;
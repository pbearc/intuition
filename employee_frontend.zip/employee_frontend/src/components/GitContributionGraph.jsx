import React, { useState, useEffect } from 'react';

const EngagementHeatmap = () => {
  const [data, setData] = useState([]);

  useEffect(() => {
    // Generate mock data with realistic patterns
    const mockData = generateMockData();
    setData(mockData);
  }, []);

  const daysOfWeek = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday']; // Define the days for each row

  // Generate mock data for 5 rows and 60 columns
  const generateMockData = () => {
    const mockData = [];

    // Create 5 rows (representing 5 different users/engagement types)
    for (let row = 0; row < 5; row++) {
      const rowData = [];
      
      // Create 60 columns (representing 60 different periods or days)
      for (let col = 0; col < 48; col++) {
        // Generate engagement value with patterns
        let value = Math.floor(Math.random() * 40); // Base random value
        
        // Add some special high engagement days
        const isSpecialDay = Math.random() < 0.05;
        if (isSpecialDay) {
          value += 30;
        }

        // Cap at 100
        value = Math.min(value, 100);

        rowData.push(value);
      }
      mockData.push(rowData);
    }

    return mockData;
  };

  // Get color based on engagement value
  const getColor = (value) => {
    if (value >= 80) return '#fb4d56'; // Bright red (high engagement)
    if (value >= 60) return '#af3a3d';
    if (value >= 40) return '#84373a';
    if (value >= 20) return '#5e2f33';
    return '#3a2e2f'; // Dark maroon (low engagement)
  };

  return (
    <div className="w-full bg-gray-900 p-4 rounded-lg">
      <div className="mb-4 flex justify-between text-white px-2">
        <div className="text-center flex-1 text-xl font-bold">Jia Yee's Services Engagement Graph</div>
      </div>

      <div className="grid grid-cols-60 gap-1">
        {data.map((rowData, rowIndex) => (
          <div key={rowIndex} className="flex items-center space-x-1 pl-5">
            <div className='text-white w-24'>
            {daysOfWeek[rowIndex]}
            </div>
            {rowData.map((value, colIndex) => (
              <div
                key={colIndex}
                className="w-4 h-4 rounded-sm"
                style={{
                  backgroundColor: getColor(value),
                  transition: 'background-color 0.3s ease',
                }}
                title={`Value: ${value}%`}
              />
            ))}
          </div>
        ))}
      </div>

      <div className="mt-4 flex justify-center">
        <div className="flex items-center">
          <span className="text-gray-400 text-xs mr-2">Less</span>
          {['#3a2e2f', '#5e2f33', '#84373a', '#af3a3d', '#fb4d56'].map(color => (
            <div 
              key={color} 
              className="w-4 h-4 mx-px rounded-sm"
              style={{ backgroundColor: color }}
            />
          ))}
          <span className="text-gray-400 text-xs ml-2">More</span>
        </div>
      </div>
    </div>
  );
};

export default EngagementHeatmap;
